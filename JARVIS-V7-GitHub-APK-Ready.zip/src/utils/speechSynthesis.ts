/**
 * Speech Synthesis helper for JARVIS V5
 */

export function cleanTextForSpeech(text: string): string {
  if (!text) return '';
  return text
    // Remove markdown code blocks
    .replace(/```[\s\S]*?```/g, 'Code block omitted.')
    // Remove inline code
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown links [title](url) -> title
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Remove bold/italics markers
    .replace(/[*_~]{1,3}/g, '')
    // Remove headers (# Title)
    .replace(/^#{1,6}\s+/gm, '')
    // Remove markdown bullet points
    .replace(/^\s*[-*+]\s+/gm, '')
    // Remove URLs
    .replace(/https?:\/\/\S+/g, '')
    // Clean excessive whitespaces or newlines
    .replace(/\s+/g, ' ')
    .trim();
}

export function deduplicateVoices(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice[] {
  if (!voices || voices.length === 0) return [];
  const seen = new Set<string>();
  const unique: SpeechSynthesisVoice[] = [];
  for (const v of voices) {
    const nameKey = (v.name || '').trim().toLowerCase();
    const uriKey = (v.voiceURI || '').trim().toLowerCase();
    const key = uriKey || nameKey || `${(v.lang || '').toLowerCase()}`;
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(v);
    }
  }
  return unique;
}

export function getAvailableVoices(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    if (!('speechSynthesis' in window)) {
      resolve([]);
      return;
    }

    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      resolve(deduplicateVoices(voices));
      return;
    }

    const handler = () => {
      const updated = window.speechSynthesis.getVoices();
      window.speechSynthesis.removeEventListener('voiceschanged', handler);
      resolve(deduplicateVoices(updated));
    };
    window.speechSynthesis.addEventListener('voiceschanged', handler);

    // Fallback if event doesn't fire
    setTimeout(() => {
      resolve(deduplicateVoices(window.speechSynthesis.getVoices()));
    }, 500);
  });
}

export function findBestVoice(
  voices: SpeechSynthesisVoice[],
  preferredURI?: string,
  preferredLang?: string
): SpeechSynthesisVoice | undefined {
  if (!voices || voices.length === 0) return undefined;

  if (preferredURI) {
    const matched = voices.find((v) => v.voiceURI === preferredURI);
    if (matched) return matched;
  }

  // If Hindi requested or preferred
  if (preferredLang === 'hi-IN' || preferredLang?.startsWith('hi')) {
    const hiVoice = voices.find((v) => v.lang.startsWith('hi'));
    if (hiVoice) return hiVoice;
  }

  // Look for Indian English (en-IN)
  const enInVoice = voices.find((v) => v.lang === 'en-IN' || v.lang.startsWith('en-IN'));
  if (enInVoice) return enInVoice;

  // Fallback to any English voice or default voice
  const defaultVoice = voices.find((v) => v.default);
  if (defaultVoice) return defaultVoice;

  const enVoice = voices.find((v) => v.lang.startsWith('en'));
  if (enVoice) return enVoice;

  return voices[0];
}

export interface SpeakOptions {
  rate?: number;
  pitch?: number;
  voiceURI?: string;
  lang?: string;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (err: any) => void;
}

export function speakText(text: string, options: SpeakOptions = {}): SpeechSynthesisUtterance | null {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported');
    options.onError?.(new Error('Speech synthesis not supported on this device/browser'));
    return null;
  }

  // Stop any ongoing speech
  stopSpeaking();

  const clean = cleanTextForSpeech(text);
  if (!clean) return null;

  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.rate = options.rate ?? 1.0;
  utterance.pitch = options.pitch ?? 1.0;

  const voices = window.speechSynthesis.getVoices();
  const selectedVoice = findBestVoice(voices, options.voiceURI, options.lang);
  if (selectedVoice) {
    utterance.voice = selectedVoice;
    utterance.lang = selectedVoice.lang;
  } else if (options.lang) {
    utterance.lang = options.lang;
  }

  utterance.onstart = () => {
    options.onStart?.();
  };

  utterance.onend = () => {
    options.onEnd?.();
  };

  utterance.onerror = (e) => {
    console.warn('Speech synthesis utterance error:', e);
    options.onError?.(e);
  };

  try {
    window.speechSynthesis.speak(utterance);
    return utterance;
  } catch (err) {
    console.error('Failed to trigger window.speechSynthesis.speak:', err);
    options.onError?.(err);
    return null;
  }
}

export function stopSpeaking(): void {
  if ('speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // ignore
    }
  }
}
