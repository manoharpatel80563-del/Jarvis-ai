export type AssistantState = 'idle' | 'listening' | 'processing' | 'speaking' | 'restarting';

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  isVoiceInput?: boolean;
  actionTaken?: string;
  actionUrl?: string;
  sources?: GroundingSource[];
  isError?: boolean;
}

export interface AppSettings {
  sttLanguage: 'hi-IN' | 'en-IN' | 'en-US';
  autoSpeak: boolean;
  speechRate: number; // 0.8 - 1.5
  speechPitch: number; // 0.8 - 1.2
  voiceURI: string;
  enableSearchGrounding: boolean;
  hapticFeedback: boolean;
}

export interface BatteryInfo {
  supported: boolean;
  level: number; // 0 - 100
  charging: boolean;
}

export interface NetworkInfo {
  online: boolean;
  type?: string;
}
