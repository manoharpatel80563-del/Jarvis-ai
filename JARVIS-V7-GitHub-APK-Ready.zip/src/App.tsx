import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AssistantState, ChatMessage, AppSettings, BatteryInfo, NetworkInfo } from './types';
import { JarvisSpeechRecognizer } from './utils/speechRecognition';
import { speakText, stopSpeaking, getAvailableVoices } from './utils/speechSynthesis';
import { checkAndExecuteSmartCommand, parseWakePhrase, isStopCommand } from './utils/smartCommands';
import { Header } from './components/Header';
import { ArcReactor } from './components/ArcReactor';
import { QuickActions } from './components/QuickActions';
import { ResponseCard } from './components/ResponseCard';
import { ConversationHistory } from './components/ConversationHistory';
import { CommandInput } from './components/CommandInput';
import { SettingsModal } from './components/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { DialerModal } from './components/DialerModal';

const DEFAULT_SETTINGS: AppSettings = {
  sttLanguage: 'hi-IN',
  autoSpeak: true,
  speechRate: 1.0,
  speechPitch: 1.0,
  voiceURI: '',
  enableSearchGrounding: false,
  hapticFeedback: true,
};

export default function App() {
  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [transcript, setTranscript] = useState<string>('');
  const [isInterim, setIsInterim] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [continuousMode, setContinuousMode] = useState<boolean>(false);

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    return [
      {
        id: 'welcome-msg',
        role: 'model',
        text: 'नमस्ते! मैं JARVIS V7 हूँ — आपका AI वॉइस असिस्टेंट।\n\nआप मुझसे हिन्दी, Hinglish, या English में बात कर सकते हैं। "Continuous Conversation" ऑन करके या "Hey Jarvis" बोलकर लगातार बातचीत करें। रुकने के लिए कभी भी "Stop Jarvis" बोलें।',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [latestMessage, setLatestMessage] = useState<ChatMessage | null>(() => messages[0]);

  // Telemetry state
  const [battery, setBattery] = useState<BatteryInfo>({ supported: false, level: 100, charging: false });
  const [network, setNetwork] = useState<NetworkInfo>({ online: true });

  // Settings & Voices
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem('jarvis_v7_settings') || localStorage.getItem('jarvis_v5_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_SETTINGS, ...parsed, enableSearchGrounding: false };
      }
    } catch {
      // ignore
    }
    return DEFAULT_SETTINGS;
  });

  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isDialerOpen, setIsDialerOpen] = useState(false);
  const [dialerNumber, setDialerNumber] = useState('');

  // Speech recognizer and lifecycle refs
  const recognizerRef = useRef<JarvisSpeechRecognizer | null>(null);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const isExecutingRef = useRef<boolean>(false);
  const isSpeakingRef = useRef<boolean>(false);
  const continuousModeRef = useRef<boolean>(false);
  const autoRestartTimerRef = useRef<number | null>(null);
  const consecutiveErrorsRef = useRef<number>(0);
  const hasHandledSpeechRef = useRef<boolean>(false);

  useEffect(() => {
    continuousModeRef.current = continuousMode;
  }, [continuousMode]);

  const clearAutoRestartTimer = () => {
    if (autoRestartTimerRef.current !== null) {
      window.clearTimeout(autoRestartTimerRef.current);
      autoRestartTimerRef.current = null;
    }
  };

  // Initialize Speech Recognizer & Voices
  useEffect(() => {
    recognizerRef.current = new JarvisSpeechRecognizer(settings.sttLanguage);

    const loadVoices = () => {
      getAvailableVoices().then((voices) => {
        setAvailableVoices(voices);
      });
    };
    loadVoices();

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.addEventListener('voiceschanged', loadVoices);
    }

    // Monitor Network Online/Offline
    const handleOnline = () => setNetwork({ online: true });
    const handleOffline = () => setNetwork({ online: false });
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Monitor Battery Status
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any).getBattery().then((batt: any) => {
        const updateBatt = () => {
          setBattery({
            supported: true,
            level: Math.round(batt.level * 100),
            charging: batt.charging,
          });
        };
        updateBatt();
        batt.addEventListener('levelchange', updateBatt);
        batt.addEventListener('chargingchange', updateBatt);
      }).catch(() => {
        // Battery status blocked
      });
    }

    return () => {
      clearAutoRestartTimer();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
      }
      stopSpeaking();
    };
  }, []);

  // Sync settings changes
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_v7_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
    if (recognizerRef.current) {
      recognizerRef.current.setLanguage(settings.sttLanguage);
    }
  }, [settings]);

  // Core Command Execution Engine
  const executeCommand = useCallback(async (commandText: string, isVoice = false) => {
    const raw = commandText.trim();
    if (!raw) return;

    if (isExecutingRef.current) {
      console.log('Skipping duplicate command execution while another is in progress:', raw);
      return;
    }
    isExecutingRef.current = true;

    // Stop speaking if currently vocalizing
    stopSpeaking();
    isSpeakingRef.current = false;
    clearAutoRestartTimer();
    setErrorMessage('');
    setAssistantState('processing');

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Add user message
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      role: 'user',
      text: raw,
      timestamp,
      isVoiceInput: isVoice,
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const wake = parseWakePhrase(raw);

      // 1. STOP COMMAND CHECK: "Stop Jarvis", "Band ho jao", "Bas Jarvis", "Stop listening", "सुनना बंद करो", "जार्विस बंद हो जाओ"
      const isStop = isStopCommand(raw) || (wake.hasWakePhrase && isStopCommand(wake.cleanedText));
      if (isStop) {
        if (recognizerRef.current) {
          recognizerRef.current.stop();
        }
        setContinuousMode(false);
        continuousModeRef.current = false;
        clearAutoRestartTimer();

        const stopReplySpoken = 'Ji, main standby mode mein hoon.';
        const stopModelMsg: ChatMessage = {
          id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          role: 'model',
          text: '🛑 **JARVIS V7**: Ji, main standby mode mein hoon.\n(जी, मैं स्टैंडबाय मोड में हूँ। पुनः शुरू करने के लिए "Hey Jarvis" बोलें या START दबाएँ।)',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setMessages((prev) => [...prev, stopModelMsg]);
        setLatestMessage(stopModelMsg);

        // Vocalize stop response without auto-restarting
        handleVocalize(stopReplySpoken, false);
        return;
      }

      // 2. WAKE PHRASE ACTIVATION
      // If user said wake phrase, activate continuous conversation mode
      if (wake.hasWakePhrase && !continuousModeRef.current) {
        setContinuousMode(true);
        continuousModeRef.current = true;
      }

      // If user ONLY said wake phrase (e.g. "Hey Jarvis", "हे जार्विस")
      if (wake.hasWakePhrase && wake.isWakeOnly) {
        setContinuousMode(true);
        continuousModeRef.current = true;

        const wakeReplySpoken = 'Ji, main sun raha hoon.';
        const wakeReplyDisplay = '🎙️ **JARVIS V7**: Ji, main sun raha hoon.\n(जी, मैं सुन रहा हूँ। कहिए सर, क्या आदेश है?)';

        const modelMsg: ChatMessage = {
          id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          role: 'model',
          text: wakeReplyDisplay,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        setMessages((prev) => [...prev, modelMsg]);
        setLatestMessage(modelMsg);

        // Auto-listen after answering wake phrase
        handleVocalize(wakeReplySpoken, true);
        return;
      }

      // Determine the effective query (strip wake phrase if present)
      const effectiveQuery = wake.hasWakePhrase && wake.cleanedText ? wake.cleanedText : raw;

      // 3. CHECK LOCAL SMART COMMANDS (Math, Time, Date, Battery, Network, Openers, Call)
      const smartResult = await checkAndExecuteSmartCommand(effectiveQuery);

      if (smartResult && smartResult.handled) {
        const modelMsg: ChatMessage = {
          id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          role: 'model',
          text: smartResult.displayText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actionTaken: smartResult.actionLabel,
          actionUrl: smartResult.actionUrl,
        };

        setMessages((prev) => [...prev, modelMsg]);
        setLatestMessage(modelMsg);

        if (smartResult.actionType === 'help') {
          setIsHelpOpen(true);
        } else if (smartResult.actionType === 'dialer' && smartResult.metadata?.number) {
          setDialerNumber(smartResult.metadata.number);
        } else if (smartResult.actionType === 'stop') {
          setContinuousMode(false);
          continuousModeRef.current = false;
          handleVocalize(smartResult.spokenReply, false);
          return;
        }

        // Vocalize response and continue conversation loop
        handleVocalize(smartResult.spokenReply, true);
        return;
      }

      // 4. ROUTE TO GEMINI AI WITH CONVERSATION HISTORY
      // Pass clean history (last 10 turns) so follow-ups like "Main kaun hoon?" or "Explain more" work accurately
      const cleanHistory = messages
        .filter((m) => !m.isError)
        .slice(-10)
        .map((m) => ({
          role: m.role === 'model' ? 'model' : 'user',
          text: m.text.replace(/\*\*[^*]+\*\*:?/g, '').trim(),
        }));

      const apiBase = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
      const res = await fetch(`${apiBase}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: effectiveQuery,
          history: cleanHistory,
          enableSearch: settings.enableSearchGrounding,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || errJson.details || `Server error (${res.status})`);
      }

      const data = await res.json();
      const reply = data.reply || 'No response from JARVIS.';

      const modelMsg: ChatMessage = {
        id: `model-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        role: 'model',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sources: data.sources || [],
      };

      setMessages((prev) => [...prev, modelMsg]);
      setLatestMessage(modelMsg);

      // Vocalize AI response and continue loop
      handleVocalize(reply, true);
    } catch (err: any) {
      console.error('Technical error in JARVIS core:', err);
      const friendlyError = 'Kshama kijiye, server se judne mein dikkat hui. Main sun raha hoon, kripya dobara bolein.';
      setErrorMessage(friendlyError);

      const errorModelMsg: ChatMessage = {
        id: `model-err-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        role: 'model',
        text: `⚠️ **सिस्टम सूचना**: ${friendlyError}\n\n*विवरण: ${err?.message || 'Server unavailable'}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isError: true,
      };

      setMessages((prev) => [...prev, errorModelMsg]);
      setLatestMessage(errorModelMsg);

      // Vocalize error and maintain continuous listening loop
      handleVocalize(friendlyError, true);
    } finally {
      isExecutingRef.current = false;
    }
  }, [messages, settings.enableSearchGrounding]);

  // Start microphone listening session
  const startListening = useCallback(() => {
    clearAutoRestartTimer();

    // CRITICAL: Never start listening while vocalizing (Jarvis must never hear itself) or processing
    if (isSpeakingRef.current || isExecutingRef.current) {
      return;
    }

    setAssistantState('listening');
    setTranscript('');
    setIsInterim(false);
    hasHandledSpeechRef.current = false;

    let recognizedText = '';

    const started = recognizerRef.current?.start({
      onStart: () => {
        consecutiveErrorsRef.current = 0;
        setAssistantState('listening');
      },
      onTranscript: (payload) => {
        setTranscript(payload.transcript);
        setIsInterim(!payload.isFinal);
        recognizedText = payload.transcript;

        if (payload.isFinal && !hasHandledSpeechRef.current) {
          hasHandledSpeechRef.current = true;
          // Temporarily stop recognition so user speech is not duplicated
          if (recognizerRef.current) {
            recognizerRef.current.stop();
          }
          setAssistantState('processing');
          executeCommand(payload.transcript, true);
        }
      },
      onError: (msg, code) => {
        console.warn('Speech recognition error event:', code, msg);

        if (code === 'not-allowed') {
          setErrorMessage('Microphone permission denied. Please allow microphone access in your browser settings.');
          setContinuousMode(false);
          continuousModeRef.current = false;
          setAssistantState('idle');
          return;
        }

        // If continuous mode is enabled and user was just silent (no-speech) or stream interrupted:
        if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
          consecutiveErrorsRef.current += 1;
          const retryDelay = consecutiveErrorsRef.current > 4 ? 1200 : 300;
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, retryDelay);
        } else {
          setAssistantState('idle');
        }
      },
      onEnd: () => {
        // If we received speech that wasn't marked final, execute it
        if (!hasHandledSpeechRef.current && recognizedText.trim()) {
          hasHandledSpeechRef.current = true;
          setAssistantState('processing');
          executeCommand(recognizedText.trim(), true);
          return;
        }

        // If continuous mode is active and we are NOT speaking or processing:
        if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 250);
        } else if (!isExecutingRef.current && !isSpeakingRef.current) {
          setAssistantState('idle');
        }
      },
    });

    if (!started) {
      if (continuousModeRef.current) {
        setAssistantState('restarting');
        clearAutoRestartTimer();
        autoRestartTimerRef.current = window.setTimeout(() => {
          if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
            startListening();
          }
        }, 500);
      } else {
        setAssistantState('idle');
      }
    }
  }, [executeCommand]);

  // Vocalize helper with continuous conversation loop support
  const handleVocalize = useCallback((text: string, shouldAutoListenAfter = true) => {
    // CRITICAL: Stop speech recognition immediately before vocalizing
    if (recognizerRef.current) {
      recognizerRef.current.stop();
    }
    clearAutoRestartTimer();

    if (!settings.autoSpeak) {
      isSpeakingRef.current = false;
      if (continuousModeRef.current && shouldAutoListenAfter) {
        setAssistantState('restarting');
        clearAutoRestartTimer();
        autoRestartTimerRef.current = window.setTimeout(() => {
          if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
            startListening();
          }
        }, 300);
      } else {
        setAssistantState('idle');
      }
      return;
    }

    isSpeakingRef.current = true;
    setAssistantState('speaking');

    const utt = speakText(text, {
      rate: settings.speechRate,
      pitch: settings.speechPitch,
      voiceURI: settings.voiceURI,
      lang: settings.sttLanguage,
      onStart: () => {
        isSpeakingRef.current = true;
        setAssistantState('speaking');
      },
      onEnd: () => {
        isSpeakingRef.current = false;
        // RESTARTING STATE:
        // After speech finishes, if continuous conversation mode is enabled, restart recognition automatically
        if (continuousModeRef.current && shouldAutoListenAfter) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 250);
        } else {
          setAssistantState('idle');
        }
      },
      onError: () => {
        isSpeakingRef.current = false;
        if (continuousModeRef.current && shouldAutoListenAfter) {
          setAssistantState('restarting');
          clearAutoRestartTimer();
          autoRestartTimerRef.current = window.setTimeout(() => {
            if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
              startListening();
            }
          }, 250);
        } else {
          setAssistantState('idle');
        }
      },
    });
    currentUtteranceRef.current = utt;
  }, [settings, startListening]);

  // Stop vocal speech
  const handleStopSpeech = useCallback(() => {
    stopSpeaking();
    isSpeakingRef.current = false;
    if (continuousModeRef.current) {
      setAssistantState('restarting');
      clearAutoRestartTimer();
      autoRestartTimerRef.current = window.setTimeout(() => {
        if (continuousModeRef.current && !isSpeakingRef.current && !isExecutingRef.current) {
          startListening();
        }
      }, 200);
    } else {
      setAssistantState('idle');
    }
  }, [startListening]);

  // Toggle Continuous Conversation Mode
  const handleToggleContinuousMode = useCallback(() => {
    if (continuousMode) {
      // Disable continuous mode
      setContinuousMode(false);
      continuousModeRef.current = false;
      clearAutoRestartTimer();
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setAssistantState('idle');
    } else {
      // Enable continuous mode
      setContinuousMode(true);
      continuousModeRef.current = true;
      setErrorMessage('');
      if (!isSpeakingRef.current && !isExecutingRef.current) {
        startListening();
      }
    }
  }, [continuousMode, startListening]);

  // Toggle Microphone manually
  const handleMicClick = useCallback(() => {
    // If currently speaking, stop speech first
    if (assistantState === 'speaking') {
      handleStopSpeech();
      return;
    }

    // If currently listening, stop recognition
    if (assistantState === 'listening') {
      clearAutoRestartTimer();
      if (recognizerRef.current) {
        recognizerRef.current.stop();
      }
      setAssistantState('idle');
      return;
    }

    // Start recognition
    startListening();
  }, [assistantState, handleStopSpeech, startListening]);

  // Initiate call via phone dialer
  const handleInitiateCall = (number: string) => {
    const cleanNum = number.replace(/\s+/g, '');
    const telLink = `tel:${cleanNum}`;
    executeCommand(`Call ${cleanNum}`, false);
    window.location.href = telLink;
  };

  return (
    <div className="min-h-screen bg-gray-950 text-cyan-50 font-sans flex flex-col justify-between selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Background Sci-Fi Grid and Glows */}
      <div className="fixed inset-0 pointer-events-none opacity-20 bg-[radial-gradient(#0891b2_1px,transparent_1px)] [background-size:24px_24px]" />
      <div className="fixed -top-40 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Header */}
      <Header
        network={network}
        battery={battery}
        autoSpeak={settings.autoSpeak}
        onToggleAutoSpeak={() => setSettings((s) => ({ ...s, autoSpeak: !s.autoSpeak }))}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
      />

      {/* Main Interactive Stage */}
      <main className="flex-1 flex flex-col items-center justify-start w-full relative z-10 pb-4">
        {/* Holographic Arc Reactor Core with Microphone */}
        <ArcReactor
          state={assistantState}
          transcript={transcript}
          isInterim={isInterim}
          onMicClick={handleMicClick}
          onStopSpeaking={handleStopSpeech}
          language={settings.sttLanguage}
          errorMessage={errorMessage}
          continuousMode={continuousMode}
          onToggleContinuousMode={handleToggleContinuousMode}
        />

        {/* Quick Actions Bar */}
        <QuickActions
          onExecuteCommand={(cmd) => executeCommand(cmd, false)}
          onOpenDialer={() => setIsDialerOpen(true)}
          onOpenHelp={() => setIsHelpOpen(true)}
          disabled={assistantState === 'processing'}
        />

        {/* Latest Response HUD */}
        <ResponseCard
          message={latestMessage}
          isSpeaking={assistantState === 'speaking'}
          onReplaySpeech={(text) => handleVocalize(text)}
          onStopSpeech={handleStopSpeech}
        />

        {/* Conversation History Drawer */}
        <ConversationHistory
          messages={messages}
          onClearHistory={() => {
            setMessages([]);
            setLatestMessage(null);
          }}
          onReplaySpeech={(text) => handleVocalize(text)}
        />
      </main>

      {/* Sticky Bottom Text Input Bar */}
      <CommandInput
        onSubmit={(text) => executeCommand(text, false)}
        disabled={assistantState === 'processing'}
        placeholder={
          settings.sttLanguage === 'hi-IN'
            ? 'यहाँ लिखें या माइक दबाकर बोलें (उदा. समय बताओ, WhatsApp खोलो)...'
            : 'Type command or question for JARVIS...'
        }
      />

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newVals) => setSettings((s) => ({ ...s, ...newVals }))}
        availableVoices={availableVoices}
      />

      <HelpModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
        onTestCommand={(cmd) => executeCommand(cmd, false)}
      />

      <DialerModal
        isOpen={isDialerOpen}
        onClose={() => setIsDialerOpen(false)}
        initialNumber={dialerNumber}
        onInitiateCall={handleInitiateCall}
      />
    </div>
  );
}
