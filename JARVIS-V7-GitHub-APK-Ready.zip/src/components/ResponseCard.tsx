import React, { useState } from 'react';
import { Volume2, VolumeX, Copy, Check, ExternalLink, Globe, Phone, AlertCircle } from 'lucide-react';
import { ChatMessage } from '../types';

interface ResponseCardProps {
  message: ChatMessage | null;
  isSpeaking: boolean;
  onReplaySpeech: (text: string) => void;
  onStopSpeech: () => void;
}

export const ResponseCard: React.FC<ResponseCardProps> = ({
  message,
  isSpeaking,
  onReplaySpeech,
  onStopSpeech,
}) => {
  const [copied, setCopied] = useState(false);

  if (!message) {
    return (
      <div className="w-full max-w-xl mx-auto px-4 my-2">
        <div className="rounded-xl border border-cyan-950 bg-gray-950/60 p-4 text-center border-dashed">
          <p className="text-xs font-mono text-cyan-600/70">
            Awaiting query. Speak into microphone or select a command above.
          </p>
        </div>
      </div>
    );
  }

  const handleCopy = () => {
    if (!message.text) return;
    navigator.clipboard.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isError = message.isError;

  return (
    <div className="w-full max-w-xl mx-auto px-4 my-2 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div
        className={`relative overflow-hidden rounded-2xl border p-4 sm:p-5 backdrop-blur-md transition-all ${
          isError
            ? 'border-red-500/40 bg-red-950/20 text-red-100 shadow-[0_0_20px_rgba(239,68,68,0.15)]'
            : 'border-cyan-500/40 bg-gray-900/80 text-cyan-50 shadow-[0_0_25px_rgba(6,182,212,0.15)]'
        }`}
      >
        {/* Top Header Row */}
        <div className="flex items-center justify-between border-b border-cyan-900/40 pb-2 mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`w-2 h-2 rounded-full ${
                isError ? 'bg-red-400' : isSpeaking ? 'bg-emerald-400 animate-ping' : 'bg-cyan-400'
              }`}
            />
            <span className="text-[11px] font-mono uppercase tracking-widest font-bold text-cyan-300">
              JARVIS RESPONSE
            </span>
            {isSpeaking && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 animate-pulse">
                VOCALIZING AUDIO
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {/* Audio Speech Controls */}
            {isSpeaking ? (
              <button
                id="btn-response-stop-audio"
                type="button"
                onClick={onStopSpeech}
                title="Stop Speech"
                className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-mono border border-emerald-500/50 bg-emerald-950/50 text-emerald-300 hover:bg-emerald-900/50"
              >
                <VolumeX className="w-3.5 h-3.5" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                id="btn-response-replay-audio"
                type="button"
                onClick={() => onReplaySpeech(message.text)}
                title="Speak Response Aloud"
                className="flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-mono border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Replay</span>
              </button>
            )}

            {/* Copy Button */}
            <button
              id="btn-response-copy"
              type="button"
              onClick={handleCopy}
              title="Copy text"
              className="p-1.5 rounded-md border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Message Content */}
        <div className="prose prose-invert max-w-none text-sm sm:text-base leading-relaxed whitespace-pre-wrap break-words text-cyan-100 font-sans">
          {message.text}
        </div>

        {/* Action Link Button (e.g. Google, YouTube, WhatsApp, Phone dialer) */}
        {message.actionUrl && (
          <div className="mt-4 pt-3 border-t border-cyan-900/40 flex flex-wrap items-center gap-2">
            <a
              id="btn-response-action-link"
              href={message.actionUrl}
              target={message.actionUrl.startsWith('tel:') ? '_self' : '_blank'}
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-cyan-400/80 bg-gradient-to-r from-cyan-950 to-sky-900 text-cyan-100 font-mono text-xs sm:text-sm font-semibold hover:border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95 transition-all"
            >
              {message.actionUrl.startsWith('tel:') ? (
                <Phone className="w-4 h-4 text-amber-400" />
              ) : (
                <ExternalLink className="w-4 h-4 text-cyan-400" />
              )}
              <span>{message.actionTaken || 'Open Action Target'}</span>
            </a>
            {message.actionUrl.startsWith('tel:') && (
              <span className="text-[11px] text-cyan-500/70 font-mono">
                Opens native phone dialer safely
              </span>
            )}
          </div>
        )}

        {/* Grounding Web Sources if available */}
        {message.sources && message.sources.length > 0 && (
          <div className="mt-4 pt-3 border-t border-cyan-900/40">
            <div className="flex items-center gap-1.5 text-[11px] font-mono text-cyan-400/80 mb-2">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>LIVE WEB GROUNDING SOURCES:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {message.sources.map((src, idx) => (
                <a
                  key={idx}
                  href={src.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-mono border border-cyan-500/20 bg-cyan-950/40 text-cyan-300 hover:border-cyan-400 hover:text-cyan-100 transition-all max-w-full truncate"
                >
                  <ExternalLink className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate max-w-[200px]">{src.title || src.uri}</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Timestamp Footer */}
        <div className="mt-3 flex items-center justify-between text-[10px] font-mono text-cyan-600/70">
          <span>SOURCE: {isError ? 'ERROR_RECOVERY' : 'JARVIS NEURAL CORE'}</span>
          <span>{message.timestamp}</span>
        </div>
      </div>
    </div>
  );
};
