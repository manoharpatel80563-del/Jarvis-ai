import React, { useState } from 'react';
import { History, Trash2, ChevronDown, ChevronUp, User, Bot, Mic, Volume2 } from 'lucide-react';
import { ChatMessage } from '../types';

interface ConversationHistoryProps {
  messages: ChatMessage[];
  onClearHistory: () => void;
  onReplaySpeech: (text: string) => void;
}

export const ConversationHistory: React.FC<ConversationHistoryProps> = ({
  messages,
  onClearHistory,
  onReplaySpeech,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  if (messages.length === 0) return null;

  return (
    <div className="w-full max-w-xl mx-auto px-4 my-2">
      {/* Header Toggle Bar */}
      <div className="rounded-xl border border-cyan-950/80 bg-gray-950/60 overflow-hidden">
        <button
          id="btn-toggle-conversation-history"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-3 flex items-center justify-between text-xs font-mono text-cyan-400/80 hover:bg-cyan-950/30 transition-colors"
        >
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-cyan-400" />
            <span className="font-bold tracking-wider uppercase">SESSION CONVERSATION LOG</span>
            <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-cyan-950 border border-cyan-800 text-cyan-300">
              {messages.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {/* Collapsible Content */}
        {isOpen && (
          <div className="p-3 border-t border-cyan-950/80 bg-gray-950/90 max-h-80 overflow-y-auto space-y-3">
            <div className="flex justify-end mb-1">
              <button
                id="btn-clear-conversation-history"
                type="button"
                onClick={onClearHistory}
                className="flex items-center gap-1 text-[11px] font-mono text-red-400/80 hover:text-red-300 p-1"
              >
                <Trash2 className="w-3 h-3" />
                <span>Clear History</span>
              </button>
            </div>

            {messages.map((msg) => {
              const isUser = msg.role === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col rounded-xl p-3 text-xs sm:text-sm border transition-all ${
                    isUser
                      ? 'border-cyan-900/40 bg-cyan-950/30 text-cyan-200 ml-4'
                      : 'border-cyan-500/20 bg-gray-900/70 text-cyan-50 mr-4'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1 text-[10px] font-mono opacity-70">
                    <div className="flex items-center gap-1">
                      {isUser ? (
                        <>
                          <User className="w-3 h-3 text-cyan-400" />
                          <span className="font-bold text-cyan-300">USER</span>
                          {msg.isVoiceInput && (
                            <span className="inline-flex items-center gap-0.5 text-cyan-400/80 ml-1">
                              <Mic className="w-2.5 h-2.5" /> Voice
                            </span>
                          )}
                        </>
                      ) : (
                        <>
                          <Bot className="w-3 h-3 text-sky-400" />
                          <span className="font-bold text-sky-300">JARVIS V5</span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span>{msg.timestamp}</span>
                      {!isUser && (
                        <button
                          type="button"
                          onClick={() => onReplaySpeech(msg.text)}
                          title="Speak"
                          className="hover:text-cyan-300"
                        >
                          <Volume2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="whitespace-pre-wrap break-words">{msg.text}</div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
