import React from 'react';
import { X, Settings, Mic, Volume2, Globe, ShieldAlert, Sparkles, ExternalLink } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  availableVoices: SpeechSynthesisVoice[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  availableVoices,
}) => {
  const uniqueVoices = React.useMemo(() => {
    if (!availableVoices || availableVoices.length === 0) return [];
    const seen = new Set<string>();
    const result: SpeechSynthesisVoice[] = [];
    for (const v of availableVoices) {
      const key = (v.voiceURI || v.name || '').trim().toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        result.push(v);
      }
    }
    return result;
  }, [availableVoices]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md max-h-[90vh] flex flex-col rounded-2xl border border-cyan-500/40 bg-gray-950 p-5 text-cyan-50 shadow-[0_0_40px_rgba(6,182,212,0.3)]">
        {/* Close Button */}
        <button
          id="btn-close-settings"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full border border-cyan-900 bg-gray-900 text-cyan-400 hover:bg-cyan-900/50"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-2 mb-2">
          <Settings className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold font-['Orbitron'] tracking-wider text-cyan-200">
            JARVIS CONFIGURATION
          </h3>
        </div>
        <p className="text-xs font-mono text-cyan-400/80 mb-4">
          Adjust voice synthesis, speech recognition, and AI intelligence protocols.
        </p>

        {/* Settings Form */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 font-mono text-xs">
          {/* Speech Recognition Language */}
          <div className="p-3 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-2">
            <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
              <Mic className="w-3.5 h-3.5 text-cyan-400" />
              <span>VOICE RECOGNITION LANGUAGE (STT)</span>
            </div>
            <select
              id="select-stt-language"
              value={settings.sttLanguage}
              onChange={(e) => onUpdateSettings({ sttLanguage: e.target.value as any })}
              className="w-full bg-gray-950 border border-cyan-900/80 rounded-lg p-2 text-cyan-100 focus:outline-none focus:border-cyan-500"
            >
              <option value="hi-IN">🇮🇳 हिन्दी / Hinglish (hi-IN) — Recommended</option>
              <option value="en-IN">🇮🇳 English (India) (en-IN)</option>
              <option value="en-US">🇺🇸 English (US) (en-US)</option>
            </select>
            <p className="text-[10px] text-cyan-500/70 font-sans">
              *Hindi (hi-IN) naturally understands Hindi, Hinglish, and English commands on Chrome.
            </p>
          </div>

          {/* Voice Output (TTS) Settings */}
          <div className="p-3 rounded-xl border border-cyan-950 bg-gray-900/60 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>AUTO-SPEAK RESPONSES</span>
              </div>
              <input
                id="checkbox-auto-speak"
                type="checkbox"
                checked={settings.autoSpeak}
                onChange={(e) => onUpdateSettings({ autoSpeak: e.target.checked })}
                className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
              />
            </div>

            {/* Voice dropdown */}
            {uniqueVoices.length > 0 && (
              <div className="space-y-1">
                <label className="text-[11px] text-cyan-400/80">SYNTHESIS VOICE</label>
                <select
                  id="select-tts-voice"
                  value={settings.voiceURI}
                  onChange={(e) => onUpdateSettings({ voiceURI: e.target.value })}
                  className="w-full bg-gray-950 border border-cyan-900/80 rounded-lg p-2 text-cyan-100 focus:outline-none focus:border-cyan-500 text-[11px] truncate"
                >
                  <option value="">Auto-detect best voice (Hindi / English)</option>
                  {uniqueVoices.map((v, idx) => (
                    <option key={`tts-voice-opt-${idx}-${v.voiceURI || v.name}`} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Speech Rate */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-cyan-400/80">SPEECH SPEED</span>
                <span className="text-cyan-300 font-mono">{settings.speechRate.toFixed(1)}x</span>
              </div>
              <input
                id="slider-speech-rate"
                type="range"
                min="0.7"
                max="1.4"
                step="0.1"
                value={settings.speechRate}
                onChange={(e) => onUpdateSettings({ speechRate: parseFloat(e.target.value) })}
                className="w-full accent-cyan-500 cursor-pointer"
              />
            </div>
          </div>

          {/* Google Search Grounding */}
          <div className="p-3 rounded-xl border border-cyan-950 bg-gray-900/60 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>GOOGLE SEARCH GROUNDING</span>
              </div>
              <p className="text-[10px] text-cyan-500/70 font-sans">
                Fetches real-time facts and citations through Gemini
              </p>
            </div>
            <input
              id="checkbox-search-grounding"
              type="checkbox"
              checked={settings.enableSearchGrounding}
              onChange={(e) => onUpdateSettings({ enableSearchGrounding: e.target.checked })}
              className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
            />
          </div>

          {/* Microphone Permission Troubleshooting Guide */}
          <div className="p-3 rounded-xl border border-cyan-900/50 bg-cyan-950/30 space-y-2 text-cyan-200">
            <div className="flex items-center gap-1.5 text-cyan-300 font-bold">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>MICROPHONE PERMISSION GUIDE</span>
            </div>
            <p className="text-[11px] font-sans leading-relaxed text-cyan-300/90">
              If the microphone shows an error or does not listen:
            </p>
            <ul className="text-[11px] font-sans space-y-1 list-disc list-inside text-cyan-400/80">
              <li>
                <strong>Chrome Android:</strong> Tap the lock/tune icon in address bar → Permissions → Allow Microphone.
              </li>
              <li>
                <strong>Iframe restrictions:</strong> In preview mode, browsers may restrict iframe microphone access. Open the app in a <strong>New Tab</strong> for 100% microphone reliability.
              </li>
              <li>
                You can also use the bottom text bar to type any query anytime!
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
