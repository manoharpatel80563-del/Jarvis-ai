import React from 'react';
import { Wifi, WifiOff, BatteryCharging, Battery, Volume2, VolumeX, Settings, HelpCircle } from 'lucide-react';
import { BatteryInfo, NetworkInfo } from '../types';

interface HeaderProps {
  network: NetworkInfo;
  battery: BatteryInfo;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  network,
  battery,
  autoSpeak,
  onToggleAutoSpeak,
  onOpenSettings,
  onOpenHelp,
}) => {
  return (
    <header className="w-full max-w-xl mx-auto px-4 pt-3 pb-2 flex items-center justify-between border-b border-cyan-950/60 bg-gray-950/80 backdrop-blur-md sticky top-0 z-30">
      {/* Brand Title */}
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
          <h1 className="text-xl sm:text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-200 to-cyan-400 font-['Orbitron']">
            J.A.R.V.I.S.
          </h1>
          <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded border border-cyan-500/40 bg-cyan-950/50 text-cyan-300">
            V6
          </span>
        </div>
        <span className="text-[10px] tracking-widest text-cyan-400/70 font-mono">
          LIVE VOICE CONVERSATION • HINDI / EN
        </span>
      </div>

      {/* Telemetry and Controls */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Network Status Badge */}
        <div
          title={network.online ? 'Network Online' : 'Network Offline'}
          className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-mono border ${
            network.online
              ? 'border-cyan-500/30 bg-cyan-950/40 text-cyan-300'
              : 'border-red-500/40 bg-red-950/40 text-red-400'
          }`}
        >
          {network.online ? <Wifi className="w-3.5 h-3.5 text-cyan-400" /> : <WifiOff className="w-3.5 h-3.5 text-red-400" />}
          <span className="hidden xs:inline text-[11px]">{network.online ? 'ONLINE' : 'OFFLINE'}</span>
        </div>

        {/* Battery Badge (if supported) */}
        {battery.supported && (
          <div
            title={`Battery: ${battery.level}% ${battery.charging ? '(Charging)' : ''}`}
            className="flex items-center gap-1 px-2 py-1 rounded-full text-xs font-mono border border-cyan-500/30 bg-cyan-950/40 text-cyan-300"
          >
            {battery.charging ? (
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            ) : (
              <Battery className="w-3.5 h-3.5 text-cyan-400" />
            )}
            <span className="text-[11px]">{battery.level}%</span>
          </div>
        )}

        {/* Mute/Unmute Audio Speech Output */}
        <button
          id="btn-toggle-voice-output"
          type="button"
          onClick={onToggleAutoSpeak}
          title={autoSpeak ? 'Voice output enabled (Click to mute)' : 'Voice output muted (Click to unmute)'}
          className={`p-2 rounded-full border transition-all ${
            autoSpeak
              ? 'border-cyan-500/50 bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/60 shadow-[0_0_12px_rgba(6,182,212,0.25)]'
              : 'border-gray-800 bg-gray-900/60 text-gray-500 hover:text-gray-300'
          }`}
        >
          {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Help Button */}
        <button
          id="btn-header-help"
          type="button"
          onClick={onOpenHelp}
          title="Command Help"
          className="p-2 rounded-full border border-cyan-500/30 bg-cyan-950/30 text-cyan-300 hover:bg-cyan-900/50 hover:text-cyan-100 transition-all"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Settings Button */}
        <button
          id="btn-header-settings"
          type="button"
          onClick={onOpenSettings}
          title="Settings"
          className="p-2 rounded-full border border-cyan-500/30 bg-cyan-950/30 text-cyan-300 hover:bg-cyan-900/50 hover:text-cyan-100 transition-all"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
