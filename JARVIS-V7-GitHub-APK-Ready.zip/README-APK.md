# JARVIS V7 — APK build

This repository is a Vite/React JARVIS app plus a Capacitor Android build workflow.

## Important
The Gemini key must stay on the server. The Android client calls `/api/chat` through `VITE_API_BASE_URL`.

## Build an APK on GitHub
1. Push this project to a GitHub repository.
2. In GitHub: Settings → Secrets and variables → Actions → Variables.
3. Add repository variable `VITE_API_BASE_URL` containing the HTTPS URL of the deployed JARVIS backend.
4. Open Actions → Build JARVIS V7 APK → Run workflow.
5. When it finishes, open the workflow run → Artifacts → `JARVIS-V7-debug-apk`.
6. Download `app-debug.apk` and install it on Android.

## Local build
npm install
npm run build:web
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug

## Voice / Hey Jarvis
The existing Web Speech implementation is retained for compatibility. Android/WebView speech support varies by device. A true system-level always-on hotword requires a native on-device wake-word engine and foreground-service integration; this project does not pretend to provide that when Android does not allow it.

## Security
Never commit `.env` or a real GEMINI_API_KEY.
