import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.jarvis.ai.v7',
  appName: 'JARVIS V7',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#05070d',
    allowMixedContent: false,
  },
};

export default config;
